plugins {
    alias(libs.plugins.androidApplication) apply false
    alias(libs.plugins.jetbrainsKotlinAndroid) apply false

    // Google services Gradle plugin
    id("com.google.gms.google-services") version "4.5.0" apply false
}