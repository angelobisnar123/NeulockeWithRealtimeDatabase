package com.example.neulocke.view

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.neulocke.R
import com.example.neulocke.presenter.HomeContract
import com.example.neulocke.presenter.HomePresenter
import com.google.android.material.button.MaterialButton

class HomeActivity : AppCompatActivity(), HomeContract.View {

    private lateinit var presenter: HomePresenter

    private lateinit var tvEmail: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvDoorStatus: TextView

    private lateinit var btnOpenDoor: MaterialButton
    private lateinit var btnChangePassword: MaterialButton
    private lateinit var btnLogout: MaterialButton


    // =========================================================
    // ON CREATE
    // =========================================================

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_home)

        // Create presenter
        presenter = HomePresenter(this)

        // Find views
        tvEmail = findViewById(R.id.tvEmail)

        tvStatus = findViewById(R.id.tvStatus)

        tvDoorStatus = findViewById(R.id.tvDoorStatus)

        btnOpenDoor = findViewById(R.id.btnOpenDoor)

        btnChangePassword =
            findViewById(R.id.btnChangePassword)

        btnLogout =
            findViewById(R.id.btnLogout)


        // Load user information
        presenter.loadDashboard()


        // =====================================================
        // OPEN DOOR BUTTON
        // =====================================================

        btnOpenDoor.setOnClickListener {

            presenter.openDoor()
        }


        // =====================================================
        // CHANGE PASSWORD
        // =====================================================

        btnChangePassword.setOnClickListener {

            startActivity(
                Intent(
                    this,
                    ChangePasswordActivity::class.java
                )
            )
        }


        // =====================================================
        // LOGOUT
        // =====================================================

        btnLogout.setOnClickListener {

            presenter.logout()
        }
    }


    // =========================================================
    // ON START
    // =========================================================

    override fun onStart() {

        super.onStart()

        if (::presenter.isInitialized) {

            presenter.listenDoorStatus()
        }
    }


    // =========================================================
    // ON RESUME
    // =========================================================

    override fun onResume() {

        super.onResume()

        if (::presenter.isInitialized) {

            presenter.loadDashboard()
        }
    }


    // =========================================================
    // ON STOP
    // =========================================================

    override fun onStop() {

        if (::presenter.isInitialized) {

            presenter.stopListeningDoorStatus()
        }

        super.onStop()
    }


    // =========================================================
    // SHOW EMAIL
    // =========================================================

    override fun showUserEmail(email: String) {

        tvEmail.text = "Email: $email"
    }


    // =========================================================
    // SHOW ACCOUNT STATUS
    // =========================================================

    override fun showUserStatus(status: String) {

        tvStatus.text = status
    }


    // =========================================================
    // SHOW DOOR STATUS
    // =========================================================

    override fun showDoorStatus(status: String) {

        tvDoorStatus.text =
            "Door Status: ${status.uppercase()}"
    }


    // =========================================================
    // OPEN DOOR LOADING
    // =========================================================

    override fun showOpenDoorLoading() {

        btnOpenDoor.isEnabled = false

        btnOpenDoor.text = "Sending..."
    }


    // =========================================================
    // HIDE OPEN DOOR LOADING
    // =========================================================

    override fun hideOpenDoorLoading() {

        btnOpenDoor.isEnabled = true

        btnOpenDoor.text = "OPEN DOOR"
    }


    // =========================================================
    // SHOW MESSAGE
    // =========================================================

    override fun showMessage(message: String) {

        Toast.makeText(
            this,
            message,
            Toast.LENGTH_SHORT
        ).show()
    }


    // =========================================================
    // LOGOUT SUCCESS
    // =========================================================

    override fun logoutSuccess() {

        val intent = Intent(
            this,
            LoginActivity::class.java
        )

        intent.flags =
            Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK

        startActivity(intent)

        finish()
    }


    // =========================================================
    // DESTROY
    // =========================================================

    override fun onDestroy() {

        if (::presenter.isInitialized) {

            presenter.destroy()
        }

        super.onDestroy()
    }
}