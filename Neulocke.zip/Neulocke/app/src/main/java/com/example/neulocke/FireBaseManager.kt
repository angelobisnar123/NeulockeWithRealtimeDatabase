package com.example.neulocke.firebase

import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener

class FirebaseManager {

    // =========================
    // FIREBASE AUTHENTICATION
    // =========================

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    // =========================
    // FIREBASE REALTIME DATABASE
    // =========================

    private val database = FirebaseDatabase.getInstance(
        "https://neulocke-3deb5-default-rtdb.asia-southeast1.firebasedatabase.app"
    )

    private val db = database.reference

    // NeoLock door
    private val doorRef = db
        .child("devices")
        .child("door01")


    // =========================================================
    // LOGIN
    // =========================================================

    fun login(
        email: String,
        password: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {

        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                onSuccess()
            }
            .addOnFailureListener { exception ->
                onError(
                    exception.message ?: "Login failed."
                )
            }
    }


    // =========================================================
    // REGISTER
    // =========================================================

    fun register(
        email: String,
        password: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {

        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                onSuccess()
            }
            .addOnFailureListener { exception ->
                onError(
                    exception.message ?: "Registration failed."
                )
            }
    }


    // =========================================================
    // PASSWORD RESET
    // =========================================================

    fun sendPasswordReset(
        email: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {

        auth.sendPasswordResetEmail(email)
            .addOnSuccessListener {
                onSuccess()
            }
            .addOnFailureListener { exception ->
                onError(
                    exception.message ?: "Password reset failed."
                )
            }
    }


    // =========================================================
    // CHANGE PASSWORD
    // =========================================================

    fun changePassword(
        currentPassword: String,
        newPassword: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {

        val user = auth.currentUser

        if (user == null) {
            onError("No user is currently logged in.")
            return
        }

        val email = user.email

        if (email == null) {
            onError("User email is unavailable.")
            return
        }

        val credential = EmailAuthProvider.getCredential(
            email,
            currentPassword
        )

        user.reauthenticate(credential)
            .addOnSuccessListener {

                user.updatePassword(newPassword)
                    .addOnSuccessListener {
                        onSuccess()
                    }
                    .addOnFailureListener { exception ->
                        onError(
                            exception.message
                                ?: "Password update failed."
                        )
                    }
            }
            .addOnFailureListener { exception ->
                onError(
                    exception.message
                        ?: "Current password is incorrect."
                )
            }
    }


    // =========================================================
    // GET CURRENT USER EMAIL
    // =========================================================

    fun getCurrentUserEmail(): String {
        return auth.currentUser?.email ?: "Unknown user"
    }


    // =========================================================
    // CHECK LOGIN
    // =========================================================

    fun isUserLoggedIn(): Boolean {
        return auth.currentUser != null
    }


    // =========================================================
    // LOGOUT
    // =========================================================

    fun logout() {
        auth.signOut()
    }


    // =========================================================
    // OPEN DOOR
    // =========================================================

    fun openDoor(
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {

        val user = auth.currentUser

        if (user == null) {
            onError("You must be logged in.")
            return
        }

        val userId = user.uid
        val email = user.email ?: "Unknown user"

        // Generate unique access log ID
        val logKey = db
            .child("accessLogs")
            .push()
            .key

        if (logKey == null) {
            onError("Unable to create access log.")
            return
        }

        /*
         * These updates happen together.
         *
         * devices/door01/command = OPEN
         *
         * This is the command that the ESP32 will listen for.
         *
         * accessLogs = records who requested the door to open.
         */

        val updates = hashMapOf<String, Any>(

            // Door command
            "/devices/door01/command" to "OPEN",

            // Information about the latest command
            "/devices/door01/lastCommandBy" to userId,

            "/devices/door01/lastCommandEmail" to email,

            "/devices/door01/lastCommandAt" to ServerValue.TIMESTAMP,

            // Access log
            "/accessLogs/$logKey/userId" to userId,

            "/accessLogs/$logKey/email" to email,

            "/accessLogs/$logKey/action" to "OPEN_COMMAND",

            "/accessLogs/$logKey/timestamp" to ServerValue.TIMESTAMP
        )

        db.updateChildren(updates)
            .addOnSuccessListener {
                onSuccess()
            }
            .addOnFailureListener { exception ->
                onError(
                    exception.message
                        ?: "Failed to send door command."
                )
            }
    }


    // =========================================================
    // LISTEN TO DOOR STATUS
    // =========================================================

    fun listenDoorStatus(
        onStatusChanged: (String) -> Unit,
        onError: (String) -> Unit
    ): ValueEventListener {

        val statusRef = doorRef.child("status")

        val listener = object : ValueEventListener {

            override fun onDataChange(snapshot: DataSnapshot) {

                val status =
                    snapshot.getValue(String::class.java)
                        ?: "UNKNOWN"

                onStatusChanged(status)
            }

            override fun onCancelled(error: DatabaseError) {

                onError(error.message)
            }
        }

        statusRef.addValueEventListener(listener)

        return listener
    }


    // =========================================================
    // REMOVE DOOR STATUS LISTENER
    // =========================================================

    fun removeDoorStatusListener(
        listener: ValueEventListener
    ) {

        doorRef
            .child("status")
            .removeEventListener(listener)
    }
}