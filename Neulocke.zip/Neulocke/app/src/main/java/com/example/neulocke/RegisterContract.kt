package com.example.neulocke.presenter

interface RegisterContract {

    interface View {
        fun showLoading()
        fun hideLoading()
        fun showError(message: String)
        fun registerSuccess()
    }

    interface Presenter {
        fun register(
            email: String,
            password: String,
            confirmPassword: String
        )

        fun validateEmail(email: String): Boolean
        fun validatePassword(password: String): Boolean
        fun destroy()
    }
}