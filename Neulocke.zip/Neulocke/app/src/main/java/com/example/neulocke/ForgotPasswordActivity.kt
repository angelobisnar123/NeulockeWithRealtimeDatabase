package com.example.neulocke.view

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.neulocke.R
import com.example.neulocke.presenter.ForgotPasswordContract
import com.example.neulocke.presenter.ForgotPasswordPresenter
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class ForgotPasswordActivity :
    AppCompatActivity(),
    ForgotPasswordContract.View {

    private lateinit var presenter: ForgotPasswordPresenter

    private lateinit var etEmail: TextInputEditText
    private lateinit var btnReset: MaterialButton
    private lateinit var progressBar: ProgressBar
    private lateinit var btnBack: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_forgot_password)

        presenter = ForgotPasswordPresenter(this)

        etEmail = findViewById(R.id.etEmail)
        btnReset = findViewById(R.id.btnReset)
        progressBar = findViewById(R.id.progressBar)
        btnBack = findViewById(R.id.btnBack)

        btnReset.setOnClickListener {

            val email = etEmail.text.toString().trim()

            presenter.sendResetEmail(email)
        }

        btnBack.setOnClickListener {
            finish()
        }
    }

    override fun showLoading() {
        progressBar.visibility = View.VISIBLE
        btnReset.isEnabled = false
    }

    override fun hideLoading() {
        progressBar.visibility = View.GONE
        btnReset.isEnabled = true
    }

    override fun showError(message: String) {
        Toast.makeText(
            this,
            message,
            Toast.LENGTH_LONG
        ).show()
    }

    override fun showSuccess(message: String) {
        Toast.makeText(
            this,
            message,
            Toast.LENGTH_LONG
        ).show()

        finish()
    }

    override fun onDestroy() {
        presenter.destroy()
        super.onDestroy()
    }
}