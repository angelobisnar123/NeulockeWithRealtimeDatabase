package com.example.neulocke.presenter

interface ChangePasswordContract {

    interface View {
        fun showLoading()
        fun hideLoading()
        fun showError(message: String)
        fun passwordChanged()
    }

    interface Presenter {
        fun changePassword(
            currentPassword: String,
            newPassword: String,
            confirmPassword: String
        )

        fun destroy()
    }
}