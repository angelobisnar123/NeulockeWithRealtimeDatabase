package com.example.neulocke.presenter

interface LoginContract {

    interface View {
        fun showLoading()
        fun hideLoading()
        fun showError(message: String)
        fun loginSuccess()
    }

    interface Presenter {
        fun login(email: String, password: String)
        fun validateEmail(email: String): Boolean
        fun validatePassword(password: String): Boolean
        fun destroy()
    }
}