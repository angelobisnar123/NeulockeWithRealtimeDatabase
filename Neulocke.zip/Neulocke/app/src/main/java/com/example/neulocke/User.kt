package com.example.neulocke.model

data class User(
    val email: String
)