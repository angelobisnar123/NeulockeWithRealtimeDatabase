package com.example.neulocke.presenter

import android.util.Patterns
import com.example.neulocke.firebase.FirebaseManager

class RegisterPresenter(
    private var view: RegisterContract.View?
) : RegisterContract.Presenter {

    private val firebaseManager = FirebaseManager()

    override fun register(
        email: String,
        password: String,
        confirmPassword: String
    ) {

        if (email.isBlank()) {
            view?.showError("Email is required.")
            return
        }

        if (!validateEmail(email)) {
            view?.showError("Please enter a valid email.")
            return
        }

        if (password.isBlank()) {
            view?.showError("Password is required.")
            return
        }

        if (!validatePassword(password)) {
            view?.showError(
                "Password must contain at least 8 characters, " +
                        "one uppercase letter, one lowercase letter, " +
                        "one number, and one special character."
            )
            return
        }

        if (confirmPassword.isBlank()) {
            view?.showError("Please confirm your password.")
            return
        }

        if (password != confirmPassword) {
            view?.showError("Passwords do not match.")
            return
        }

        view?.showLoading()

        firebaseManager.register(
            email,
            password,
            {
                view?.hideLoading()
                view?.registerSuccess()
            },
            { error ->
                view?.hideLoading()
                view?.showError(error)
            }
        )
    }

    override fun validateEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    override fun validatePassword(password: String): Boolean {

        val hasUppercase = password.any { it.isUpperCase() }
        val hasLowercase = password.any { it.isLowerCase() }
        val hasNumber = password.any { it.isDigit() }

        val specialCharacters = "!@#$%^&*()_+-=[]{}|;:',.<>?/`~"
        val hasSpecial = password.any {
            specialCharacters.contains(it)
        }

        return password.length >= 8 &&
                hasUppercase &&
                hasLowercase &&
                hasNumber &&
                hasSpecial
    }

    override fun destroy() {
        view = null
    }
}