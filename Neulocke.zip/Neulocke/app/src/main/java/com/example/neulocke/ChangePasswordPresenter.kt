package com.example.neulocke.presenter

import com.example.neulocke.firebase.FirebaseManager

class ChangePasswordPresenter(
    private var view: ChangePasswordContract.View?
) : ChangePasswordContract.Presenter {

    private val firebaseManager = FirebaseManager()

    override fun changePassword(
        currentPassword: String,
        newPassword: String,
        confirmPassword: String
    ) {

        if (currentPassword.isBlank()) {
            view?.showError("Current password is required.")
            return
        }

        if (!validatePassword(newPassword)) {
            view?.showError(
                "New password must contain at least 8 characters, " +
                        "one uppercase letter, one lowercase letter, " +
                        "one number, and one special character."
            )
            return
        }

        if (newPassword == currentPassword) {
            view?.showError(
                "New password must be different from your current password."
            )
            return
        }

        if (newPassword != confirmPassword) {
            view?.showError("Passwords do not match.")
            return
        }

        view?.showLoading()

        firebaseManager.changePassword(
            currentPassword,
            newPassword,
            {
                view?.hideLoading()
                view?.passwordChanged()
            },
            { error ->
                view?.hideLoading()
                view?.showError(error)
            }
        )
    }

    private fun validatePassword(password: String): Boolean {

        val hasUppercase = password.any { it.isUpperCase() }
        val hasLowercase = password.any { it.isLowerCase() }
        val hasNumber = password.any { it.isDigit() }

        val specialCharacters = "!@#$%^&*()_+-=[]{}|;:',.<>?/`~"

        val hasSpecial = password.any {
            specialCharacters.contains(it)
        }

        return password.length >= 8 &&
                hasUppercase &&
                hasLowercase &&
                hasNumber &&
                hasSpecial
    }

    override fun destroy() {
        view = null
    }
}