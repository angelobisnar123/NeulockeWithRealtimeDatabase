package com.example.neulocke.presenter

interface ForgotPasswordContract {

    interface View {
        fun showLoading()
        fun hideLoading()
        fun showError(message: String)
        fun showSuccess(message: String)
    }

    interface Presenter {
        fun sendResetEmail(email: String)
        fun destroy()
    }
}