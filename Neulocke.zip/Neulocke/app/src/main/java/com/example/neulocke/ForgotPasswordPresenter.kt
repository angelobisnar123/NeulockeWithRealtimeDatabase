package com.example.neulocke.presenter

import android.util.Patterns
import com.example.neulocke.firebase.FirebaseManager

class ForgotPasswordPresenter(
    private var view: ForgotPasswordContract.View?
) : ForgotPasswordContract.Presenter {

    private val firebaseManager = FirebaseManager()

    override fun sendResetEmail(email: String) {

        if (email.isBlank()) {
            view?.showError("Email is required.")
            return
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            view?.showError("Please enter a valid email.")
            return
        }

        view?.showLoading()

        firebaseManager.sendPasswordReset(
            email,
            {
                view?.hideLoading()
                view?.showSuccess(
                    "Password reset email sent."
                )
            },
            { error ->
                view?.hideLoading()
                view?.showError(error)
            }
        )
    }

    override fun destroy() {
        view = null
    }
}