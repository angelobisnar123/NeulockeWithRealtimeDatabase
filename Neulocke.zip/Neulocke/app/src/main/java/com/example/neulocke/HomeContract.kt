package com.example.neulocke.presenter

interface HomeContract {

    interface View {

        fun showUserEmail(email: String)

        fun showUserStatus(status: String)

        fun showDoorStatus(status: String)

        fun showOpenDoorLoading()

        fun hideOpenDoorLoading()

        fun showMessage(message: String)

        fun logoutSuccess()
    }


    interface Presenter {

        fun loadDashboard()

        fun openDoor()

        fun listenDoorStatus()

        fun stopListeningDoorStatus()

        fun logout()

        fun destroy()
    }
}