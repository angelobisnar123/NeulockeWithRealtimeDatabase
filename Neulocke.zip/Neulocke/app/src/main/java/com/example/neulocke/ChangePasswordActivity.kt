package com.example.neulocke.view

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.neulocke.R
import com.example.neulocke.presenter.ChangePasswordContract
import com.example.neulocke.presenter.ChangePasswordPresenter
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class ChangePasswordActivity : AppCompatActivity(), ChangePasswordContract.View {

    private lateinit var presenter: ChangePasswordPresenter

    private lateinit var etCurrentPassword: TextInputEditText
    private lateinit var etNewPassword: TextInputEditText
    private lateinit var etConfirmPassword: TextInputEditText

    private lateinit var btnChangePassword: MaterialButton
    private lateinit var btnBack: MaterialButton
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_change_password)

        presenter = ChangePasswordPresenter(this)

        etCurrentPassword =
            findViewById(R.id.etCurrentPassword)

        etNewPassword =
            findViewById(R.id.etNewPassword)

        etConfirmPassword =
            findViewById(R.id.etConfirmPassword)

        btnChangePassword =
            findViewById(R.id.btnChangePassword)

        btnBack = findViewById(R.id.btnBack)

        progressBar = findViewById(R.id.progressBar)

        btnChangePassword.setOnClickListener {

            presenter.changePassword(
                etCurrentPassword.text.toString(),
                etNewPassword.text.toString(),
                etConfirmPassword.text.toString()
            )
        }

        btnBack.setOnClickListener {
            finish()
        }
    }

    override fun showLoading() {
        progressBar.visibility = View.VISIBLE
        btnChangePassword.isEnabled = false
    }

    override fun hideLoading() {
        progressBar.visibility = View.GONE
        btnChangePassword.isEnabled = true
    }

    override fun showError(message: String) {
        Toast.makeText(
            this,
            message,
            Toast.LENGTH_LONG
        ).show()
    }

    override fun passwordChanged() {

        Toast.makeText(
            this,
            "Password changed successfully!",
            Toast.LENGTH_LONG
        ).show()

        finish()
    }

    override fun onDestroy() {
        presenter.destroy()
        super.onDestroy()
    }
}