package com.example.neulocke.presenter

import com.example.neulocke.firebase.FirebaseManager
import com.google.firebase.database.ValueEventListener

class HomePresenter(
    private var view: HomeContract.View?
) : HomeContract.Presenter {

    private val firebaseManager = FirebaseManager()

    private var doorStatusListener: ValueEventListener? = null


    // =========================================================
    // LOAD DASHBOARD
    // =========================================================

    override fun loadDashboard() {

        val email = firebaseManager.getCurrentUserEmail()

        view?.showUserEmail(email)

        if (firebaseManager.isUserLoggedIn()) {

            view?.showUserStatus(
                "Account Status: Active"
            )

        } else {

            view?.showUserStatus(
                "Account Status: Not Logged In"
            )
        }
    }


    // =========================================================
    // OPEN DOOR
    // =========================================================

    override fun openDoor() {

        if (!firebaseManager.isUserLoggedIn()) {

            view?.showMessage(
                "Please log in first."
            )

            return
        }

        view?.showOpenDoorLoading()

        firebaseManager.openDoor(

            onSuccess = {

                view?.hideOpenDoorLoading()

                view?.showMessage(
                    "Door open command sent."
                )
            },

            onError = { error ->

                view?.hideOpenDoorLoading()

                view?.showMessage(
                    error
                )
            }
        )
    }


    // =========================================================
    // LISTEN TO DOOR STATUS
    // =========================================================

    override fun listenDoorStatus() {

        if (doorStatusListener != null) {
            return
        }

        doorStatusListener =
            firebaseManager.listenDoorStatus(

                onStatusChanged = { status ->

                    view?.showDoorStatus(status)
                },

                onError = { error ->

                    view?.showMessage(
                        "Door status error: $error"
                    )
                }
            )
    }


    // =========================================================
    // STOP LISTENING
    // =========================================================

    override fun stopListeningDoorStatus() {

        doorStatusListener?.let {

            firebaseManager.removeDoorStatusListener(it)
        }

        doorStatusListener = null
    }


    // =========================================================
    // LOGOUT
    // =========================================================

    override fun logout() {

        firebaseManager.logout()

        view?.logoutSuccess()
    }


    // =========================================================
    // DESTROY
    // =========================================================

    override fun destroy() {

        stopListeningDoorStatus()

        view = null
    }
}