package com.example.neulocke.presenter

import android.util.Patterns
import com.example.neulocke.firebase.FirebaseManager

class LoginPresenter(
    private var view: LoginContract.View?
) : LoginContract.Presenter {

    private val firebaseManager = FirebaseManager()

    override fun login(email: String, password: String) {

        if (email.isBlank()) {
            view?.showError("Email is required.")
            return
        }

        if (!validateEmail(email)) {
            view?.showError("Please enter a valid email.")
            return
        }

        if (password.isBlank()) {
            view?.showError("Password is required.")
            return
        }

        if (!validatePassword(password)) {
            view?.showError("Password must be at least 8 characters.")
            return
        }

        view?.showLoading()

        firebaseManager.login(
            email,
            password,
            {
                view?.hideLoading()
                view?.loginSuccess()
            },
            { error ->
                view?.hideLoading()
                view?.showError(error)
            }
        )
    }

    override fun validateEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    override fun validatePassword(password: String): Boolean {
        return password.length >= 8
    }

    override fun destroy() {
        view = null
    }
}